library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use ieee.std_logic_unsigned.all;
use ieee.math_real.all;
--
-- Copyright (C) 2007, Peter C. Wallace, Mesa Electronics
-- http://www.mesanet.com
--
-- This program is is licensed under a disjunctive dual license giving you
-- the choice of one of the two following sets of free software/open source
-- licensing terms:
--
--    * GNU General Public License (GPL), version 2.0 or later
--    * 3-clause BSD License
-- 
--
-- The GNU GPL License:
-- 
--     This program is free software; you can redistribute it and/or modify
--     it under the terms of the GNU General Public License as published by
--     the Free Software Foundation; either version 2 of the License, or
--     (at your option) any later version.
-- 
--     This program is distributed in the hope that it will be useful,
--     but WITHOUT ANY WARRANTY; without even the implied warranty of
--     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--     GNU General Public License for more details.
-- 
--     You should have received a copy of the GNU General Public License
--     along with this program; if not, write to the Free Software
--     Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301 USA
-- 
-- 
-- The 3-clause BSD License:
-- 
--     Redistribution and use in source and binary forms, with or without
--     modification, are permitted provided that the following conditions
--     are met:
-- 
--         * Redistributions of source code must retain the above copyright
--           notice, this list of conditions and the following disclaimer.
-- 
--         * Redistributions in binary form must reproduce the above
--           copyright notice, this list of conditions and the following
--           disclaimer in the documentation and/or other materials
--           provided with the distribution.
-- 
--         * Neither the name of Mesa Electronics nor the names of its
--           contributors may be used to endorse or promote products
--           derived from this software without specific prior written
--           permission.
-- 
-- 
-- Disclaimer:
-- 
--     THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
--     "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
--     LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
--     FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
--     COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
--     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
--     BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
--     LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
--     CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
--     LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
--     ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
--     POSSIBILITY OF SUCH DAMAGE.
-- 

entity cpdrive is  -- nominal 1 MHz non-overlap highside/low side charge pump drive for simple PS
    generic ( clock : integer);
	 port ( ibus : in  std_logic;
           loadena : in  std_logic;
           high : out  std_logic;
			  low : out  std_logic;
			  clk : in std_logic);
			  
end cpdrive;

architecture Behavioral of cpdrive is
constant defaultdivisor : real := round((real(clock)/8000000.0)) -2.0; -- nominal 8 MHz /8 so 1 MHz
signal rate: std_logic_vector(5 downto 0) := std_logic_vector(to_unsigned(integer(defaultdivisor),6)); 
signal count: std_logic_vector (5 downto 0);
signal state: std_logic_vector (2 downto 0);
signal enable: std_logic := '1';
signal qlow: std_logic;
signal qhigh: std_logic;
alias  countmsb: std_logic is  count(5);

begin
	acpdrv: process (clk,count)
	begin
		report("CPDrive Rate Divisor: "& real'image(defaultdivisor));
		if rising_edge(clk) then	
			if countmsb= '0' then 
				count <= count -1;
			else
				count <= rate;
				state <= state +1;
				if state < 3 then 
					qhigh <= '1';
				else 
					qhigh <= '0'; 		-- 3/8 duty cycle high
				end if;
				if (state > 3) and (state < 7) then 
					qlow <= '0'; 
				else 
					qlow <= '1'; 		-- 3/8 duty cycle low
				end if;
			end if;
			if loadena = '1' then
			   enable <= ibus;
			end if;
		end if;	
		if enable = '1' then
			low <= qlow;
			high <= qhigh;
		else
			low <= '1';
			high <= '0';
		end if;	
	end process;

end Behavioral;
